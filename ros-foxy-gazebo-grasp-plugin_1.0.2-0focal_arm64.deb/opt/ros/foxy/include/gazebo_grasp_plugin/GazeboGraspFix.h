#ifndef GAZEBO_GAZEBOGRASPFIX_H
#define GAZEBO_GAZEBOGRASPFIX_H

//#include <boost/bind.hpp>
#include <gazebo_ros/node.hpp>
#include <gazebo/gazebo.hh>
#include <gazebo/physics/physics.hh>
#include <gazebo/common/Plugin.hh>
#include <gazebo/transport/TransportTypes.hh>
#include <stdio.h>
#include "rclcpp/rclcpp.hpp"
#include <memory>
#include <gazebo_ros/conversions/builtin_interfaces.hpp>

#include <gazebo_grasp_plugin/GazeboGraspGripper.h>
#include "action_msgs/srv/cancel_goal.hpp"

namespace gazebo_plugins
{
    class GazeboGraspFixPrivate;
    
    class GazeboGraspFix : public gazebo::ModelPlugin
    {
    public:
        // Constructor
        GazeboGraspFix();
        GazeboGraspFix(gazebo::physics::ModelPtr _model);

        // Destructor
        virtual ~GazeboGraspFix() override;

        /**
         * Gets called just after the object has been attached to the palm link on \e armName
         */
        virtual void OnAttach(const std::string &objectName,
                              const std::string &armName) {}
        /**
         * Gets called just after the object has been detached to the palm link on \e armName
         */
        virtual void OnDetach(const std::string &objectName,
                              const std::string &armName) {}


    protected:
        virtual void Load(gazebo::physics::ModelPtr _parent, sdf::ElementPtr _sdf) override;
        
    private:
        virtual void Init();

        void OnUpdate(const gazebo::common::UpdateInfo & _info);
        void InitValues();

        void OnContact(const ConstContactsPtr &ptr);

//    bool CheckGrip(const std::vector<GzVector3> &forces, float minAngleDiff,
//                   float lengthRatio);

        bool IsGripperLink(const std::string &linkName, std::string &gripperName) const;

        /**
         * return objects (key) and the gripper (value) to which it is attached
         */
        std::map<std::string, std::string> GetAttachedObjects() const;

        /**
         * Helper class to collect contact info per object.
         * Forward declaration here.
         */
        class ObjectContactInfo;

        /**
         * Helper function to determine if object attached to a gripper in ObjectContactInfo.
         */
        bool ObjectAttachedToGripper(const ObjectContactInfo &objContInfo,
                                     std::string &attachedToGripper) const;

        /**
         * Helper function to determine if object attached to this gripper
         */
        bool ObjectAttachedToGripper(const std::string &gripperName,
                                     std::string &attachedToGripper) const;

        
        // gazebo::physics::ModelPtr model;
        // gazebo::physics::PhysicsEnginePtr physics;
        gazebo::physics::WorldPtr world;

        // sorted by their name, all grippers of the robot
        std::map<std::string, gazebo::GazeboGraspGripper> grippers;

        gazebo::transport::NodePtr node;
        gazebo::transport::SubscriberPtr contactSub; //subscriber to contact updates
        

        // tolerance (in degrees) between force vectors to
        // beconsidered "opposing"
        float forcesAngleTolerance;
        
        // when an object is attached, collisions with it may be disabled, in case the
        // robot still keeps wobbling.
        bool disableCollisionsOnAttach;

        // all collisions per gazebo collision link (each entry
        // belongs to a physics::CollisionPtr element). The key
        // is the collision link name, the value is the gripper name
        // this collision link belongs to.
        std::map<std::string, std::string> collisions;


        /**
         * Helper class to encapsulate a collision information. Forward declaration here.
         */
        class CollidingPoint;
        
        // Contact forces sorted by object name the gripper collides with (first key)
        // and the link colliding (second key).
        std::map<std::string, std::map<std::string, CollidingPoint> > contacts;
        boost::mutex mutexContacts; //mutex protects contacts

        
        // when an object was first attached, it had these colliding points.
        // First key is object name, second is the link colliding, as in \e contacts.
        // Only the links of *one* gripper are stored here. This indirectly imposes the
        // limitation that no two grippers can grasp the object (while it would be
        // possible, the release condition is tied to only one link, so the object may
        // not be released properly).
        std::map<std::string, std::map<std::string, CollidingPoint> >
        attachGripContacts;


        // Records how many subsequent update calls the grip on that object has been recorded
        // as "holding". Every loop, if a grip is not recorded, this number decreases.
        // When it reaches \e grip_count_threshold, it will be attached.
        // The number won't increase above max_grip_count once it has reached that number.
        std::map<std::string, int> gripCounts;

        // *maximum* number in \e gripCounts to be recorded.
        int maxGripCount;

        // number of recorded "grips" in the past (in gripCount) which, when it is exceeded, counts
        // as the object grasped, and when it is lower, as released.
        int gripCountThreshold;
        

        // once an object is gripped, the relative position of the collision link surface to the
        // object is remembered. As soon as this distance changes more than release_tolerance,
        // the object is released.
        float releaseTolerance;


        //nano seconds between two updates
        gazebo::common::Time updateRate;

        //last time OnUpdate() was called
        gazebo::common::Time prevUpdateTime;
        
        //ContactManager filter to be removed in destructor
        std::string filter_name;

        //Data pointer
        std::unique_ptr<GazeboGraspFixPrivate> impl_;
        
    };

}

#endif
